﻿app.service("CustomerService", function ($http) {

    //Get All
    this.GetAll = function () {
        return $http.get("Customer/GetAll");
    }

    this.GetById = function (id) {
        var response = $http({
            method: "post",
            url: "Customer/GetById",
            params: {
                id: JSON.stringify(id)
            }
        });
        return response;
    };
    //Add
    this.Add = function (value) {
        var response = $http({
            method: "post",
            url: "Customer/Create",
            data: JSON.stringify(value),
            dataType: "json"
        });
        return response;
    }

    //Update
    this.Update = function (value) {
        var response = $http({
            method: "post",
            url: "Customer/Edit",
            data: JSON.stringify(value),
            dataType: "json"
        });
        return response;
    };

    this.Delete = function (value) {
        var response = $http({
            method: "post",
            url: "Customer/Delete",
            params: {
                id: JSON.stringify(value)
            }
        });
        return response;
    }

})