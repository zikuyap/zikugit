﻿app.controller("CustomerCtrl", function ($scope, CustomerService) {


    getAll();

    function getAll() {
        debugger;
        var getData = CustomerService.GetAll();
        getData.then(function (value) {
            $scope.List = value.data;
            
        }, function () {
            alert('Error in getting records');
        });
    }


    $scope.AddDialog = function () {
        $('#userModel').modal('show');
        $scope.Action = "Add";
        
    }

    $scope.EditDialog = function (formData) {
        var getData = CustomerService.GetById(formData.Id);
        getData.then(function (value) {
            $scope.formData = value.data;
            $scope.CustomerId = formData.Id;
            $scope.CustomerName = formData.Name;
            $scope.CustomerAge = formData.Age;
            $scope.CustomerMobile = formData.Mobile;

            $scope.Action = "Update";
            $("#userModel").modal('show');
        }, function () {
            alert('Error in getting records');
        });
    }
    

    $scope.AddOrUpdate = function () {
        var modelData = {
            Name: $scope.CustomerName,
            Age: $scope.CustomerAge,
            Mobile: $scope.CustomerMobile
            
        };

        var getAction = $scope.Action;

        if (getAction == "Update") {
            modelData.Id = $scope.CustomerId;
            var getUpdateData = CustomerService.Update(modelData);
            getUpdateData.then(function (msg) {
                getAll();
                alert(msg.data);
               // $scope.editMode = false;
                $('#userModel').modal('hide');

            }, function () {
                alert('Error in updating record');
            });
        } else {
            debugger;
            var getAddData = CustomerService.Add(modelData);
            getAddData.then(function (msg) {
                getAll();
                alert(msg.data);
                $scope.divAdd = false;
                $('#userModel').modal('hide');
            }, function () {
                alert('Error in adding record');
            });
        }
    }

    $scope.Delete = function (data) {
        var getData = CustomerService.Delete(data.Id);
        getData.then(function (msg) {
            $('#confirmModal').modal('hide');
            alert(msg.data);
            getAll();
        }, function () {
            alert('Error in deleting record');
        });
    }

    $scope.DeleteConfirm = function (data) {
        $scope.n = data;
        $("#confirmModal").modal('show');
    }
})
