﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;
using System.Data.Entity.Migrations;

namespace WebApplication1.Controllers
{
    public class CustomerController : Controller
    {
        private TestEntities db = new TestEntities();
        //
        // GET: /Customer/
        public ActionResult Index()
        {
            return View();
        }

        public JsonResult GetAll()
        {
            var objcustomer = db.Customers.ToList();
            return Json(objcustomer,JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetById(int? id)
        {
            var getid = db.Customers.Find(id);
            return Json(getid, JsonRequestBehavior.AllowGet);
        }
        public string Create(Customer customer)
        {
            var existingcustomer = db.Customers.Where(d => (d.Name == customer.Name)).FirstOrDefault();
            if (existingcustomer == null)
            {
                db.Customers.Add(customer);
                db.SaveChanges();
                
                return "Added successfully";
            }
            
            return "Added failed";
        }
        public string Edit( Customer customer)
        {
            var existingDesignation = db.Customers.Where(e => e.Id == customer.Id).FirstOrDefault();
            existingDesignation.Name = customer.Name;
            existingDesignation.Age = customer.Age;
            existingDesignation.Mobile = customer.Mobile;
            db.Customers.AddOrUpdate(existingDesignation);
            db.SaveChanges();
            return "Update Successfully";
        }
        public string Delete(int? id)
        {
                 var delete = db.Customers.Find(id);
                db.Customers.Remove(delete);
                db.SaveChanges();
                return "Deleted Successfully";
        }
	}
}